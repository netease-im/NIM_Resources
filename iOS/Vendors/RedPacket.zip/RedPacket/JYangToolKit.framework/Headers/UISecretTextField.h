//
//  UISecretTextField.h
//  RedEnvelopeDemo
//
//  Created by 一路财富 on 16/3/31.
//  Copyright © 2016年 一路财富. All rights reserved.
//
//  不允许复制粘贴的UITextFied

#import <UIKit/UIKit.h>

@interface UISecretTextField : UITextField

@end
