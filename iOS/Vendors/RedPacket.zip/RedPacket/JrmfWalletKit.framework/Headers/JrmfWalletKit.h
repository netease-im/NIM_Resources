//
//  JrmfWalletKit.h
//  JrmfWalletKit
//
//  Created by 一路财富 on 16/10/17.
//  Copyright © 2016年 JYang. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for JrmfWalletKit.
FOUNDATION_EXPORT double JrmfWalletKitVersionNumber;

//! Project version string for JrmfWalletKit.
FOUNDATION_EXPORT const unsigned char JrmfWalletKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JrmfWalletKit/PublicHeader.h>

#import <JrmfWalletKit/JrmfWalletSDK.h>
